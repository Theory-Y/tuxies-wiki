# Logitech Linux Setup

This folder gives your Logitech mouse and keyboard the same kind of custom buttons and
pop-up action menu you'd get from **Logi Options+** on Windows or macOS — but on Linux,
using two free apps: **Solaar** (button remapping) and **Kando** (the radial "Actions Ring"
menu).

You don't need to understand the config files. The included `install.sh` script copies the
ready-made presets into the right places for you, and walks you through each step.

> 📖 New here? Read the full [Logitech Linux Setup guide](../../docs/guides/logitech-linux-setup.md)
> first — it shows what each remapped button does and includes screenshots.

## Before you start

Install both apps **first** — the presets only do something once the apps exist:

- **Solaar** — `sudo dnf install solaar` (Fedora) · `sudo apt install solaar` (Debian/Ubuntu) · `sudo pacman -S solaar` (Arch) · or Flatpak `io.github.pwr_solaar.solaar`
- **Kando** — see the [guide](../../docs/guides/logitech-linux-setup.md) for per-distro instructions

If neither a Flatpak nor a native install is found, the script still copies the configs to the
native location and warns you — they'll start working once you install the app.

## How to use it

```bash
cd logitech-linux-setup
chmod +x install.sh
./install.sh
```

The installer is interactive and safe:

- It shows you each preset and lets you inspect or edit it (in `nano`) before anything is written.
- It asks `[y/n]` before each step, so you're always in control.
- It backs up any existing config (with a timestamp) before overwriting.
- It auto-detects whether each app is installed as a Flatpak or a native package. Force one with
  `--flatpak` or `--native` if needed.

> 💡 Quit Solaar before running so it picks up the new rules on next launch. Kando hot-reloads,
> so its menus apply right away.

## What's in here

| File / folder   | What it is                                                                       |
| --------------- | ------------------------------------------------------------------------------- |
| `install.sh`    | The interactive installer.                                                      |
| `solaar/`       | The Solaar button-remap preset — `rules.yaml`.                                  |
| `kando/`        | The Kando Actions Ring config — installed as `config.json` and `menus.json`.    |

Device-specific settings like DPI, backlight, and haptics are stored per physical device and
**aren't** included here — set those in the Solaar app after pairing.
